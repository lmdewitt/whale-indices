<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis simplifyDrawingHints="1" simplifyMaxScale="1" simplifyLocal="1" minScale="100000000" maxScale="0" readOnly="0" version="3.16.3-Hannover" simplifyAlgorithm="0" styleCategories="AllStyleCategories" labelsEnabled="0" simplifyDrawingTol="1" hasScaleBasedVisibilityFlag="0">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
  </flags>
  <temporal enabled="0" durationField="" accumulate="0" startExpression="" endField="" durationUnit="min" fixedDuration="0" endExpression="" mode="0" startField="">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <renderer-v2 enableorderby="0" type="RuleRenderer" forceraster="0" symbollevels="0">
    <rules key="{9a0567a5-c61f-4a76-8f06-1a539eaf7899}">
      <rule key="{f41ef637-1b80-4fe8-a116-45fd21bf54c3}" filter="&quot;DUN_MJ2011&quot;>0 AND &quot;DUN_MJ2011&quot; &lt;21" label="&lt; 21" symbol="0"/>
      <rule key="{7d13c616-ccc3-44f5-a803-67b8c69048f8}" filter="&quot;DUN_MJ2011&quot;>=21 AND &quot;DUN_MJ2011&quot; &lt;=35" label="21 to 35" symbol="1"/>
      <rule key="{ec1c391c-3d04-4085-983f-dd4b9a69c65d}" filter="&quot;DUN_MJ2011&quot;>=36 AND &quot;DUN_MJ2011&quot; &lt;=70" label="36 to 70" symbol="2"/>
      <rule key="{bf44f3de-bd56-48d6-8c5c-60d62e1efd7d}" filter="&quot;DUN_MJ2011&quot;>=71 AND &quot;DUN_MJ2011&quot; &lt;=140" label="71 to 140" symbol="3"/>
      <rule key="{1bc3c2ba-7f0a-4e05-aa08-79e7914d94e0}" filter="&quot;DUN_MJ2011&quot;>=141 AND &quot;DUN_MJ2011&quot; &lt;=280" label="141 to 280" symbol="4"/>
      <rule key="{980013af-e635-40b0-adc5-26b3e41f4fc4}" filter="&quot;DUN_MJ2011&quot;>=281 AND &quot;DUN_MJ2011&quot; &lt;=560" label="281 to 560" symbol="5"/>
      <rule key="{36e5819e-bc05-488c-bc77-08b72da5a296}" filter="&quot;DUN_MJ2011&quot;>560" label="> 560" symbol="6"/>
    </rules>
    <symbols>
      <symbol alpha="1" clip_to_extent="1" name="0" force_rhr="0" type="fill">
        <layer enabled="1" pass="0" locked="0" class="SimpleFill">
          <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
          <prop v="69,117,180,255" k="color"/>
          <prop v="bevel" k="joinstyle"/>
          <prop v="0,0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="35,35,35,255" k="outline_color"/>
          <prop v="no" k="outline_style"/>
          <prop v="0.26" k="outline_width"/>
          <prop v="MM" k="outline_width_unit"/>
          <prop v="solid" k="style"/>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" clip_to_extent="1" name="1" force_rhr="0" type="fill">
        <layer enabled="1" pass="0" locked="0" class="SimpleFill">
          <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
          <prop v="132,158,185,255" k="color"/>
          <prop v="bevel" k="joinstyle"/>
          <prop v="0,0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="35,35,35,255" k="outline_color"/>
          <prop v="no" k="outline_style"/>
          <prop v="0.26" k="outline_width"/>
          <prop v="MM" k="outline_width_unit"/>
          <prop v="solid" k="style"/>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" clip_to_extent="1" name="2" force_rhr="0" type="fill">
        <layer enabled="1" pass="0" locked="0" class="SimpleFill">
          <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
          <prop v="192,203,189,255" k="color"/>
          <prop v="bevel" k="joinstyle"/>
          <prop v="0,0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="35,35,35,255" k="outline_color"/>
          <prop v="no" k="outline_style"/>
          <prop v="0.26" k="outline_width"/>
          <prop v="MM" k="outline_width_unit"/>
          <prop v="solid" k="style"/>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" clip_to_extent="1" name="3" force_rhr="0" type="fill">
        <layer enabled="1" pass="0" locked="0" class="SimpleFill">
          <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
          <prop v="255,255,188,255" k="color"/>
          <prop v="bevel" k="joinstyle"/>
          <prop v="0,0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="35,35,35,255" k="outline_color"/>
          <prop v="no" k="outline_style"/>
          <prop v="0" k="outline_width"/>
          <prop v="MM" k="outline_width_unit"/>
          <prop v="solid" k="style"/>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" clip_to_extent="1" name="4" force_rhr="0" type="fill">
        <layer enabled="1" pass="0" locked="0" class="SimpleFill">
          <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
          <prop v="247,181,127,255" k="color"/>
          <prop v="bevel" k="joinstyle"/>
          <prop v="0,0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="35,35,35,255" k="outline_color"/>
          <prop v="no" k="outline_style"/>
          <prop v="0" k="outline_width"/>
          <prop v="MM" k="outline_width_unit"/>
          <prop v="solid" k="style"/>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" clip_to_extent="1" name="5" force_rhr="0" type="fill">
        <layer enabled="1" pass="0" locked="0" class="SimpleFill">
          <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
          <prop v="236,117,82,255" k="color"/>
          <prop v="bevel" k="joinstyle"/>
          <prop v="0,0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="35,35,35,255" k="outline_color"/>
          <prop v="no" k="outline_style"/>
          <prop v="0.26" k="outline_width"/>
          <prop v="MM" k="outline_width_unit"/>
          <prop v="solid" k="style"/>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" clip_to_extent="1" name="6" force_rhr="0" type="fill">
        <layer enabled="1" pass="0" locked="0" class="SimpleFill">
          <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
          <prop v="213,46,38,255" k="color"/>
          <prop v="bevel" k="joinstyle"/>
          <prop v="0,0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="35,35,35,255" k="outline_color"/>
          <prop v="no" k="outline_style"/>
          <prop v="0.26" k="outline_width"/>
          <prop v="MM" k="outline_width_unit"/>
          <prop v="solid" k="style"/>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <customproperties>
    <property key="dualview/previewExpressions" value="&quot;GRID5KM_ID&quot;"/>
    <property key="embeddedWidgets/count" value="0"/>
    <property key="variableNames"/>
    <property key="variableValues"/>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer attributeLegend="1" diagramType="Histogram">
    <DiagramCategory maxScaleDenominator="1e+8" labelPlacementMethod="XHeight" sizeScale="3x:0,0,0,0,0,0" spacingUnit="MM" spacingUnitScale="3x:0,0,0,0,0,0" backgroundColor="#ffffff" penAlpha="255" sizeType="MM" lineSizeScale="3x:0,0,0,0,0,0" scaleDependency="Area" opacity="1" rotationOffset="270" width="15" penWidth="0" showAxis="1" direction="0" barWidth="5" spacing="5" height="15" lineSizeType="MM" penColor="#000000" backgroundAlpha="255" minimumSize="0" enabled="0" scaleBasedVisibility="0" minScaleDenominator="0" diagramOrientation="Up">
      <fontProperties description="Ubuntu,11,-1,5,50,0,0,0,0,0" style=""/>
      <attribute field="" label="" color="#000000"/>
      <axisSymbol>
        <symbol alpha="1" clip_to_extent="1" name="" force_rhr="0" type="line">
          <layer enabled="1" pass="0" locked="0" class="SimpleLine">
            <prop v="0" k="align_dash_pattern"/>
            <prop v="square" k="capstyle"/>
            <prop v="5;2" k="customdash"/>
            <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
            <prop v="MM" k="customdash_unit"/>
            <prop v="0" k="dash_pattern_offset"/>
            <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
            <prop v="MM" k="dash_pattern_offset_unit"/>
            <prop v="0" k="draw_inside_polygon"/>
            <prop v="bevel" k="joinstyle"/>
            <prop v="35,35,35,255" k="line_color"/>
            <prop v="solid" k="line_style"/>
            <prop v="0.26" k="line_width"/>
            <prop v="MM" k="line_width_unit"/>
            <prop v="0" k="offset"/>
            <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
            <prop v="MM" k="offset_unit"/>
            <prop v="0" k="ring_filter"/>
            <prop v="0" k="tweak_dash_pattern_on_corners"/>
            <prop v="0" k="use_custom_dash"/>
            <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
            <data_defined_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings obstacle="0" linePlacementFlags="18" priority="0" dist="0" showAll="1" zIndex="0" placement="1">
    <properties>
      <Option type="Map">
        <Option value="" name="name" type="QString"/>
        <Option name="properties"/>
        <Option value="collection" name="type" type="QString"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions removeDuplicateNodes="0" geometryPrecision="0">
    <activeChecks/>
    <checkConfiguration type="Map">
      <Option name="QgsGeometryGapCheck" type="Map">
        <Option value="0" name="allowedGapsBuffer" type="double"/>
        <Option value="false" name="allowedGapsEnabled" type="bool"/>
        <Option value="" name="allowedGapsLayer" type="QString"/>
      </Option>
    </checkConfiguration>
  </geometryOptions>
  <legend type="default-vector"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field name="GRID5KM_ID" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="STATE" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DUN_NF1011" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DUN_MJ2011" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DUN_JO2011" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DUN_NF1112" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DUN_MJ2012" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DUN_JO2012" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DUN_NF1213" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DUN_MJ2013" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DUN_JO2013" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DUN_NF1314" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DUN_MJ2014" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DUN_JO2014" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DUN_NF1415" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DUN_MJ2015" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DUN_JO2015" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DUN_NF1516" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DUN_MJ2016" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DUN_10TO11" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DUN_11TO12" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DUN_12TO13" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DUN_13TO14" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DUN_14TO15" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DUN_15TO16" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="GRID5KM_ID" index="0" name=""/>
    <alias field="STATE" index="1" name=""/>
    <alias field="DUN_NF1011" index="2" name=""/>
    <alias field="DUN_MJ2011" index="3" name=""/>
    <alias field="DUN_JO2011" index="4" name=""/>
    <alias field="DUN_NF1112" index="5" name=""/>
    <alias field="DUN_MJ2012" index="6" name=""/>
    <alias field="DUN_JO2012" index="7" name=""/>
    <alias field="DUN_NF1213" index="8" name=""/>
    <alias field="DUN_MJ2013" index="9" name=""/>
    <alias field="DUN_JO2013" index="10" name=""/>
    <alias field="DUN_NF1314" index="11" name=""/>
    <alias field="DUN_MJ2014" index="12" name=""/>
    <alias field="DUN_JO2014" index="13" name=""/>
    <alias field="DUN_NF1415" index="14" name=""/>
    <alias field="DUN_MJ2015" index="15" name=""/>
    <alias field="DUN_JO2015" index="16" name=""/>
    <alias field="DUN_NF1516" index="17" name=""/>
    <alias field="DUN_MJ2016" index="18" name=""/>
    <alias field="DUN_10TO11" index="19" name=""/>
    <alias field="DUN_11TO12" index="20" name=""/>
    <alias field="DUN_12TO13" index="21" name=""/>
    <alias field="DUN_13TO14" index="22" name=""/>
    <alias field="DUN_14TO15" index="23" name=""/>
    <alias field="DUN_15TO16" index="24" name=""/>
  </aliases>
  <defaults>
    <default expression="" field="GRID5KM_ID" applyOnUpdate="0"/>
    <default expression="" field="STATE" applyOnUpdate="0"/>
    <default expression="" field="DUN_NF1011" applyOnUpdate="0"/>
    <default expression="" field="DUN_MJ2011" applyOnUpdate="0"/>
    <default expression="" field="DUN_JO2011" applyOnUpdate="0"/>
    <default expression="" field="DUN_NF1112" applyOnUpdate="0"/>
    <default expression="" field="DUN_MJ2012" applyOnUpdate="0"/>
    <default expression="" field="DUN_JO2012" applyOnUpdate="0"/>
    <default expression="" field="DUN_NF1213" applyOnUpdate="0"/>
    <default expression="" field="DUN_MJ2013" applyOnUpdate="0"/>
    <default expression="" field="DUN_JO2013" applyOnUpdate="0"/>
    <default expression="" field="DUN_NF1314" applyOnUpdate="0"/>
    <default expression="" field="DUN_MJ2014" applyOnUpdate="0"/>
    <default expression="" field="DUN_JO2014" applyOnUpdate="0"/>
    <default expression="" field="DUN_NF1415" applyOnUpdate="0"/>
    <default expression="" field="DUN_MJ2015" applyOnUpdate="0"/>
    <default expression="" field="DUN_JO2015" applyOnUpdate="0"/>
    <default expression="" field="DUN_NF1516" applyOnUpdate="0"/>
    <default expression="" field="DUN_MJ2016" applyOnUpdate="0"/>
    <default expression="" field="DUN_10TO11" applyOnUpdate="0"/>
    <default expression="" field="DUN_11TO12" applyOnUpdate="0"/>
    <default expression="" field="DUN_12TO13" applyOnUpdate="0"/>
    <default expression="" field="DUN_13TO14" applyOnUpdate="0"/>
    <default expression="" field="DUN_14TO15" applyOnUpdate="0"/>
    <default expression="" field="DUN_15TO16" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint notnull_strength="0" field="GRID5KM_ID" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint notnull_strength="0" field="STATE" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint notnull_strength="0" field="DUN_NF1011" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint notnull_strength="0" field="DUN_MJ2011" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint notnull_strength="0" field="DUN_JO2011" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint notnull_strength="0" field="DUN_NF1112" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint notnull_strength="0" field="DUN_MJ2012" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint notnull_strength="0" field="DUN_JO2012" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint notnull_strength="0" field="DUN_NF1213" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint notnull_strength="0" field="DUN_MJ2013" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint notnull_strength="0" field="DUN_JO2013" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint notnull_strength="0" field="DUN_NF1314" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint notnull_strength="0" field="DUN_MJ2014" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint notnull_strength="0" field="DUN_JO2014" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint notnull_strength="0" field="DUN_NF1415" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint notnull_strength="0" field="DUN_MJ2015" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint notnull_strength="0" field="DUN_JO2015" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint notnull_strength="0" field="DUN_NF1516" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint notnull_strength="0" field="DUN_MJ2016" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint notnull_strength="0" field="DUN_10TO11" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint notnull_strength="0" field="DUN_11TO12" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint notnull_strength="0" field="DUN_12TO13" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint notnull_strength="0" field="DUN_13TO14" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint notnull_strength="0" field="DUN_14TO15" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint notnull_strength="0" field="DUN_15TO16" unique_strength="0" constraints="0" exp_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint field="GRID5KM_ID" exp="" desc=""/>
    <constraint field="STATE" exp="" desc=""/>
    <constraint field="DUN_NF1011" exp="" desc=""/>
    <constraint field="DUN_MJ2011" exp="" desc=""/>
    <constraint field="DUN_JO2011" exp="" desc=""/>
    <constraint field="DUN_NF1112" exp="" desc=""/>
    <constraint field="DUN_MJ2012" exp="" desc=""/>
    <constraint field="DUN_JO2012" exp="" desc=""/>
    <constraint field="DUN_NF1213" exp="" desc=""/>
    <constraint field="DUN_MJ2013" exp="" desc=""/>
    <constraint field="DUN_JO2013" exp="" desc=""/>
    <constraint field="DUN_NF1314" exp="" desc=""/>
    <constraint field="DUN_MJ2014" exp="" desc=""/>
    <constraint field="DUN_JO2014" exp="" desc=""/>
    <constraint field="DUN_NF1415" exp="" desc=""/>
    <constraint field="DUN_MJ2015" exp="" desc=""/>
    <constraint field="DUN_JO2015" exp="" desc=""/>
    <constraint field="DUN_NF1516" exp="" desc=""/>
    <constraint field="DUN_MJ2016" exp="" desc=""/>
    <constraint field="DUN_10TO11" exp="" desc=""/>
    <constraint field="DUN_11TO12" exp="" desc=""/>
    <constraint field="DUN_12TO13" exp="" desc=""/>
    <constraint field="DUN_13TO14" exp="" desc=""/>
    <constraint field="DUN_14TO15" exp="" desc=""/>
    <constraint field="DUN_15TO16" exp="" desc=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig actionWidgetStyle="dropDown" sortOrder="0" sortExpression="&quot;DUN_NF1011&quot;">
    <columns>
      <column hidden="0" width="-1" name="GRID5KM_ID" type="field"/>
      <column hidden="0" width="-1" name="STATE" type="field"/>
      <column hidden="0" width="-1" name="DUN_NF1011" type="field"/>
      <column hidden="0" width="-1" name="DUN_MJ2011" type="field"/>
      <column hidden="0" width="-1" name="DUN_JO2011" type="field"/>
      <column hidden="0" width="-1" name="DUN_NF1112" type="field"/>
      <column hidden="0" width="-1" name="DUN_MJ2012" type="field"/>
      <column hidden="0" width="-1" name="DUN_JO2012" type="field"/>
      <column hidden="0" width="-1" name="DUN_NF1213" type="field"/>
      <column hidden="0" width="-1" name="DUN_MJ2013" type="field"/>
      <column hidden="0" width="-1" name="DUN_JO2013" type="field"/>
      <column hidden="0" width="-1" name="DUN_NF1314" type="field"/>
      <column hidden="0" width="-1" name="DUN_MJ2014" type="field"/>
      <column hidden="0" width="-1" name="DUN_JO2014" type="field"/>
      <column hidden="0" width="-1" name="DUN_NF1415" type="field"/>
      <column hidden="0" width="-1" name="DUN_MJ2015" type="field"/>
      <column hidden="0" width="-1" name="DUN_JO2015" type="field"/>
      <column hidden="0" width="-1" name="DUN_NF1516" type="field"/>
      <column hidden="0" width="-1" name="DUN_MJ2016" type="field"/>
      <column hidden="0" width="-1" name="DUN_10TO11" type="field"/>
      <column hidden="0" width="-1" name="DUN_11TO12" type="field"/>
      <column hidden="0" width="-1" name="DUN_12TO13" type="field"/>
      <column hidden="0" width="-1" name="DUN_13TO14" type="field"/>
      <column hidden="0" width="-1" name="DUN_14TO15" type="field"/>
      <column hidden="0" width="-1" name="DUN_15TO16" type="field"/>
      <column hidden="1" width="-1" type="actions"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
	geom = feature.geometry()
	control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field editable="1" name="DUN_10TO11"/>
    <field editable="1" name="DUN_11TO12"/>
    <field editable="1" name="DUN_12TO13"/>
    <field editable="1" name="DUN_13TO14"/>
    <field editable="1" name="DUN_14TO15"/>
    <field editable="1" name="DUN_15TO16"/>
    <field editable="1" name="DUN_JO2011"/>
    <field editable="1" name="DUN_JO2012"/>
    <field editable="1" name="DUN_JO2013"/>
    <field editable="1" name="DUN_JO2014"/>
    <field editable="1" name="DUN_JO2015"/>
    <field editable="1" name="DUN_MJ2011"/>
    <field editable="1" name="DUN_MJ2012"/>
    <field editable="1" name="DUN_MJ2013"/>
    <field editable="1" name="DUN_MJ2014"/>
    <field editable="1" name="DUN_MJ2015"/>
    <field editable="1" name="DUN_MJ2016"/>
    <field editable="1" name="DUN_NF1011"/>
    <field editable="1" name="DUN_NF1112"/>
    <field editable="1" name="DUN_NF1213"/>
    <field editable="1" name="DUN_NF1314"/>
    <field editable="1" name="DUN_NF1415"/>
    <field editable="1" name="DUN_NF1516"/>
    <field editable="1" name="GRID5KM_ID"/>
    <field editable="1" name="STATE"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="0" name="DUN_10TO11"/>
    <field labelOnTop="0" name="DUN_11TO12"/>
    <field labelOnTop="0" name="DUN_12TO13"/>
    <field labelOnTop="0" name="DUN_13TO14"/>
    <field labelOnTop="0" name="DUN_14TO15"/>
    <field labelOnTop="0" name="DUN_15TO16"/>
    <field labelOnTop="0" name="DUN_JO2011"/>
    <field labelOnTop="0" name="DUN_JO2012"/>
    <field labelOnTop="0" name="DUN_JO2013"/>
    <field labelOnTop="0" name="DUN_JO2014"/>
    <field labelOnTop="0" name="DUN_JO2015"/>
    <field labelOnTop="0" name="DUN_MJ2011"/>
    <field labelOnTop="0" name="DUN_MJ2012"/>
    <field labelOnTop="0" name="DUN_MJ2013"/>
    <field labelOnTop="0" name="DUN_MJ2014"/>
    <field labelOnTop="0" name="DUN_MJ2015"/>
    <field labelOnTop="0" name="DUN_MJ2016"/>
    <field labelOnTop="0" name="DUN_NF1011"/>
    <field labelOnTop="0" name="DUN_NF1112"/>
    <field labelOnTop="0" name="DUN_NF1213"/>
    <field labelOnTop="0" name="DUN_NF1314"/>
    <field labelOnTop="0" name="DUN_NF1415"/>
    <field labelOnTop="0" name="DUN_NF1516"/>
    <field labelOnTop="0" name="GRID5KM_ID"/>
    <field labelOnTop="0" name="STATE"/>
  </labelOnTop>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"GRID5KM_ID"</previewExpression>
  <mapTip></mapTip>
  <layerGeometryType>2</layerGeometryType>
</qgis>
